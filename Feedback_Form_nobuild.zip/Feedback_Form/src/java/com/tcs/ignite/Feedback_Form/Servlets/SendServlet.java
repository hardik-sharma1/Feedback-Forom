/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ignite.Feedback_Form.Servlets;

import com.tcs.ignite.Feedback_Form.Beans.EmployeeFeedback;
import com.tcs.ignite.Feedback_Form.Services.UserService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ignite348
 */
public class SendServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
      PrintWriter out = response.getWriter();
      String ignite_id = request.getParameter("IgId");
      String name = request.getParameter("name");
      String locaion   = request.getParameter("location");
      String feedback  = request.getParameter("feedback");
      EmployeeFeedback ef = new  EmployeeFeedback();
      ef.setIgniteId(ignite_id);
      ef.setLocation(locaion);
      ef.setName(name);
      ef.setDescription(feedback);
      UserService us = new UserService();
      ef = us.addData(ef);
      if(ef!=null)
      {
          out.println("fail");
      }
      else
      {
          out.println("success");
      }
    }
}
