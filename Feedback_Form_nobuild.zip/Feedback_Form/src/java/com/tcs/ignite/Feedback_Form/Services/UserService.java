/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ignite.Feedback_Form.Services;

import com.tcs.ignite.Feedback_Form.Beans.EmployeeFeedback;

import net.sf.ehcache.hibernate.HibernateUtil;
import org.hibernate.Session;




/**
 *
 * @author ignite348
 */
public class UserService {

    public EmployeeFeedback addData(EmployeeFeedback ef) {
            Session session = null;
            try
            {
             session = HibernateUtil.getSessionFactory().openSession();
             
            }
            catch(Exception ec)
            {
              
                
            }
            finally
            {
                
            }
    }
            
    
}
